<?php
/**
 * @package bxr
 */
class BXRItem extends xPDOSimpleObject {}