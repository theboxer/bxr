--------------------
BXR
--------------------
Version: 0.1.0
Author: Jan Peca <pecajan@gmail.com>
--------------------

This is only testing ground for ExtJS components.